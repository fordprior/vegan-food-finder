class Animal
  def make_noise
    "Moo!"
  end
end

animal1 = Animal.new
puts animal1.make_noise

animal2 = Animal.new
puts animal2.make_noise
