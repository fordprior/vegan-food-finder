# This file is a transcript of the IRB session shown in the movie.
# You should be able to cut and paste it into IRB to get 
# the same results shown in the comments.

# irb
x + 2
# NameError: undefined local variable or method `x' for main:Object from (irb):1
x = 1
# => 1
x + 2
# => 3
puts x + 2
# 3
# => nil
first_variable = 3
# => 3
aw_counter = 100
# => 100
articles_written = 100
# => 100
var = 1
# => 1
a = 100
# => 100
b = a
# => 100
b
# => 100
a = 50
# => 50
b
# => 100
quit
